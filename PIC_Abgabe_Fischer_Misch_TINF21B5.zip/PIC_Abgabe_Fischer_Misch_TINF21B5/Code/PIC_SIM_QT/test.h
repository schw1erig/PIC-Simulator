#include "qobject.h"
#include <iostream>

void testSetStatus();
void testAddwf();
void testProgAblauf();
void testSyncDataSpeicher();
void testSetPS();

/*
class progAblauf : public QObject
{
    Q_OBJECT
public:
    explicit progAblauf(QObject *parent = 0);
    void call();
signals:
    void testProgAblauf();

public slots:

};
*/
