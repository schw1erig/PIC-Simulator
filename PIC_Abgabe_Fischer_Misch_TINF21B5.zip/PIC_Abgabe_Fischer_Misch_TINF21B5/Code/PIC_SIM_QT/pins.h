#ifndef PINS_H
#define PINS_H

#endif // PINS_H

#include <string>

using namespace std;

void pin_action();
int getFlanke(int oldValue, int newValue);

