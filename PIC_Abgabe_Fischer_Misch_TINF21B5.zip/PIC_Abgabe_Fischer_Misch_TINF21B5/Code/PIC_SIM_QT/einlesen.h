#include <string>

using namespace std;

void resetPIC();
void wdtResetPIC();
void bootPIC();

void einlesen(string filename);
void fileAusgeben();
void extractBefehle();
void addSpaces();
